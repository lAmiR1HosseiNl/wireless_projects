import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
import seaborn as sns

def analyze_mobility_shadowing(folder_name):
    print(f"Starting analysis for folder: {folder_name}...")
    
    # 1. Load all CSV files and keep track of file origin
    all_files = [f for f in os.listdir(folder_name) if f.endswith('.csv')]
    all_segments_data = []
    
    for file in all_files:
        path = os.path.join(folder_name, file)
        df = pd.read_csv(path)
        df['trace_file'] = file # Tag file for segmentation
        all_segments_data.append(df)
    
    full_df = pd.concat(all_segments_data, ignore_index=True)
    
    # 2. Data Cleaning
    total_raw_samples = len(full_df)
    
    # 2.1 Filter LTE
    full_df = full_df[full_df['NetworkMode'] == 'LTE']
    lte_count = len(full_df)
    
    # 2.2 Convert to numeric and Drop NaNs
    cols_to_numeric = ['RSRP', 'ServingCell_Distance', 'CellID', 'Speed']
    for col in cols_to_numeric:
        full_df[col] = pd.to_numeric(full_df[col], errors='coerce')
    
    pre_nan_drop = len(full_df)
    full_df = full_df.dropna(subset=['RSRP', 'ServingCell_Distance', 'CellID'])
    post_nan_drop = len(full_df)
    
    # 2.3 Distance > 0 filter
    full_df = full_df[full_df['ServingCell_Distance'] >= 1]
    final_cleaned_count = len(full_df)
    
    print(f"\n[DATA FLOW DIAGNOSTIC]")
    print(f"Total Raw Samples: {total_raw_samples}")
    print(f"Dropped (Non-LTE): {total_raw_samples - lte_count}")
    print(f"Dropped (NaN in Distance/RSRP/CID): {pre_nan_drop - post_nan_drop}")
    print(f"Dropped (Distance < 1m): {post_nan_drop - final_cleaned_count}")
    print(f"Samples entering Clusters: {final_cleaned_count}\n")

    # 3. Segmentation by (CellID, Trace File)
    grouped = full_df.groupby(['trace_file', 'CellID'])
    
    # Adaptive thresholds based on mobility pattern
    is_static = 'static' in folder_name.lower()
    min_samples_threshold = 15 if is_static else 20
    min_dist_threshold = 5 if is_static else 100
    r2_threshold = 0.01 if is_static else 0.1
    n_min, n_max = (-2.0, 10.0) if is_static else (1.0, 6.0)

    segment_results = []
    all_shadowing_residuals = []
    total_valid_samples = 0
    total_outliers_removed = 0
    
    # Detailed exclusion counters
    excl_small_samples = 0
    excl_small_distance = 0
    excl_low_correlation = 0 # Low R2 or bad n
    
    print(f"Initial clusters (File+CellID): {len(grouped)}")

    for (fname, cid), group in grouped:
        # 3.1 Min samples
        if len(group) < min_samples_threshold: 
            excl_small_samples += 1
            continue
        
        dists = group['ServingCell_Distance'].values
        rsrp = group['RSRP'].values
        dist_min, dist_max = np.min(dists), np.max(dists)
        avg_speed = group['Speed'].mean()
        
        # 3.2 Distance Spread
        if (dist_max - dist_min) < min_dist_threshold:
            excl_small_distance += 1
            continue
        
        # Log distance regression
        X = 10 * np.log10(dists).reshape(-1, 1)
        Y = rsrp
        
        # Handle cases where all distances are identical (Static)
        if np.all(X == X[0]):
            X = X + np.random.normal(0, 0.0001, X.shape) # Add tiny noise to allow regression
            
        model = LinearRegression()
        model.fit(X, Y)
        n_local = -model.coef_[0]
        r2_local = model.score(X, Y)
        intercept_C = model.intercept_
        
        # 3.3 Quality Filter
        if n_min < n_local < n_max and r2_local >= r2_threshold:
            y_pred = model.predict(X)
            residuals = Y - y_pred
            
            # Intra-segment Outlier Removal
            local_sigma = np.std(residuals)
            mask = np.abs(residuals) < (3 * local_sigma)
            
            if mask.sum() < (min_samples_threshold - 5): 
                excl_low_correlation += 1
                continue
                
            total_outliers_removed += (len(group) - mask.sum())
            
            # Re-calculate with cleaned points
            X_clean, Y_clean = X[mask], Y[mask]
            model.fit(X_clean, Y_clean)
            
            res_val = Y_clean - model.predict(X_clean)
            
            segment_results.append({
                'id': f"{cid} ({fname[:12]}...)",
                'samples': len(X_clean),
                'speed': avg_speed,
                'dist_range': f"{int(dist_min)}-{int(dist_max)}",
                'n': -model.coef_[0],
                'sigma': np.std(res_val),
                'r2': model.score(X_clean, Y_clean),
                'C': model.intercept_,
                'X': X_clean,
                'Y': Y_clean,
                'y_pred': model.predict(X_clean)
            })
            
            all_shadowing_residuals.extend(res_val)
            total_valid_samples += len(X_clean)
        else:
            excl_low_correlation += 1

    if not segment_results:
        print("Error: No valid segments found after filtering.")
        return

    from scipy import stats # Added for scientific validation

    # 4. Statistical Synthesis & Advanced Validation
    n_vals = np.array([s['n'] for s in segment_results])
    sigma_vals = [s['sigma'] for s in segment_results]
    r2_vals = [s['r2'] for s in segment_results]
    
    # 4.1 Confidence Interval for Global Sigma (Chi-square)
    residuals = np.array(all_shadowing_residuals)
    N_res = len(residuals)
    s2 = np.var(residuals, ddof=1)
    alpha = 0.05
    chi2_low, chi2_high = stats.chi2.ppf([alpha/2, 1-alpha/2], df=N_res-1)
    sigma_ci = (np.sqrt((N_res-1)*s2 / chi2_high), np.sqrt((N_res-1)*s2 / chi2_low))
    
    # 4.2 Normality Test (Shapiro-Wilk) - using subset if too large
    sw_stat, sw_p = stats.shapiro(residuals[:5000]) if N_res > 3 else (0, 0)
    
    # 4.3 Bootstrap CI for Median n
    B = 5000
    boot_medians = [np.median(np.random.choice(n_vals, size=len(n_vals), replace=True)) for _ in range(B)]
    n_median_ci = np.percentile(boot_medians, [2.5, 97.5])
    final_n_median = np.median(n_vals)
    final_sigma_global = np.sqrt(s2)

    # 4.4 Sensitivity Check: Exclude low-R2 (<0.2)
    filtered_segs = [s for s in segment_results if s['r2'] >= 0.2]
    if filtered_segs:
        combined_res_filt = np.hstack([s['Y'] - s['y_pred'] for s in filtered_segs])
        sigma_filt = np.std(combined_res_filt)
        n_median_filt = np.median([s['n'] for s in filtered_segs])
    else:
        sigma_filt, n_median_filt = 0, 0

    # 4.5 Detailed TXT Logging
    txt_path = os.path.join(folder_name, f'result_{os.path.basename(folder_name)}.txt')
    with open(txt_path, 'w', encoding='utf-8') as f:
        f.write("="*100 + "\n")
        f.write(f" SCIENTIFIC REPORT: {os.path.basename(folder_name).upper()} MOBILITY (RELIABILITY ANALYSIS)\n")
        f.write(f" STATUS: Representative for studied {os.path.basename(folder_name)} routes\n")
        f.write("="*100 + "\n\n")
        
        f.write(f"[1. DATA QUALITY BREAKDOWN]\n")
        f.write(f"- Total Raw Samples: {total_raw_samples}\n")
        f.write(f"- Final Valid Samples Used: {total_valid_samples}\n")
        f.write(f"- Final Valid Segments: {len(segment_results)}\n")
        f.write(f"- Excluded (Low Fit Quality R2 < 0.1): {excl_low_correlation}\n\n")
        
        f.write(f"[2. PER-SEGMENT DETAIL TABLE]\n")
        header = f"{'Segment (CellID + File)':<35} | {'Samples':<10} | {'Speed(kmh)':<12} | {'n':<10} | {'sigma':<10} | {'R2':<10} | {'Context':<10}\n"
        f.write(header)
        f.write("-" * len(header) + "\n")
        for s in segment_results:
            quality_mark = "*" if s['r2'] < 0.2 else " "
            context = "Stationary" if s['speed'] < 5 else "In-Route"
            f.write(f"{s['id']+quality_mark:<35} | {s['samples']:<10} | {s['speed']:<12.1f} | {s['n']:<10.2f} | {s['sigma']:<10.2f} | {s['r2']:<10.2f} | {context:<10}\n")
        f.write("\n(*) denotes R2 < 0.2\n")

        f.write(f"\n[3. STATISTICAL VALIDATION & CONFIDENCE]\n")
        f.write(f"- Path Loss Exponent (Median n): {final_n_median:.4f} [95% CI: {n_median_ci[0]:.3f} - {n_median_ci[1]:.3f}]\n")
        f.write(f"- Shadowing Std Dev (Global sigma): {final_sigma_global:.4f} dB [95% CI: {sigma_ci[0]:.3f} - {sigma_ci[1]:.3f}]\n")
        f.write(f"- Shapiro-Wilk Normality test (p-value): {sw_p:.4e}\n")
        f.write(f"- Note: Residuals are {'Likely Gaussian' if sw_p > 0.05 else 'Non-Gaussian'}.\n")
        f.write("  Interpretation: Non-Gaussian residuals are expected due to spatial correlation, handover effects, and mixed LOS/NLOS conditions.\n")
        
        f.write(f"\n[4. SENSITIVITY ANALYSIS (High-Quality Segments R2 >= 0.2)]\n")
        f.write(f"- Filtered Median n: {n_median_filt:.4f}\n")
        f.write(f"- Filtered Global sigma: {sigma_filt:.4f} dB\n")
        f.write(f"- Valid High-Quality Segments: {len(filtered_segs)}\n")

    print("-" * 30)
    print(f"Grand report saved to: {txt_path}")

    # 5. Advanced Visualization
    plt.figure(figsize=(20, 16))
    plt.suptitle(f'Scientific 4G Shadowing Analysis - {os.path.basename(folder_name).upper()}\n(Filtered Dataset: n={final_n_median:.2f}, σ={final_sigma_global:.2f}dB)', 
                 fontsize=22, fontweight='bold')

    # Plot 1: Representative Segment Trends
    plt.subplot(3, 2, 1)
    try:
        from matplotlib import colormaps
        cmap = colormaps['tab10']
    except ImportError:
        cmap = plt.cm.get_cmap('tab10')
    
    for idx, s in enumerate(segment_results[:5]):
        color = cmap(idx % 10)
        plt.scatter(s['X'], s['Y'], alpha=0.3, s=8, color=color)
        plt.plot(s['X'], s['y_pred'], color=color, linewidth=2.5, label=f"Seg {idx+1} (n={s['n']:.2f}, R2={s['r2']:.2f})")
    plt.xlabel('10 * log10(Distance)')
    plt.ylabel('RSRP (dBm)')
    plt.title('Top Valid Segment Trends')
    plt.legend(fontsize=9)
    plt.grid(True, alpha=0.3)

    # Plot 2: Global Shadowing Histogram + Normal Fit
    plt.subplot(3, 2, 2)
    sns.histplot(all_shadowing_residuals, kde=True, color='forestgreen', stat="density")
    mu, std = 0, final_sigma_global
    x_range = np.linspace(-4*std, 4*std, 100)
    p = (1/(std * np.sqrt(2 * np.pi))) * np.exp(-0.5 * ((x_range - mu) / std)**2)
    plt.plot(x_range, p, 'k', linewidth=2.5, label='Approx. Gaussian Fit')
    plt.xlabel('Shadowing Noise (dB)')
    plt.title(f'Shadowing Variance (σ={final_sigma_global:.2f} dB)')
    plt.legend()
    plt.grid(True, alpha=0.3)

    # Plot 3: Boxplots for n and Sigma
    plt.subplot(3, 2, 3)
    data_to_plot = [n_vals, sigma_vals]
    try:
        box = plt.boxplot(data_to_plot, patch_artist=True, tick_labels=['Exponent (n)', 'Local Sigma (dB)'])
    except TypeError:
        box = plt.boxplot(data_to_plot, patch_artist=True, labels=['Exponent (n)', 'Local Sigma (dB)'])
    for patch, color in zip(box['boxes'], ['lightblue', 'lightgreen']):
        patch.set_facecolor(color)
    plt.title('Statistical Distribution of Parameters')
    plt.grid(True, axis='y', alpha=0.3)

    # Plot 4: Path Loss Exponent (n) vs. Average Speed
    plt.subplot(3, 2, 4)
    avg_speeds = [s['speed'] for s in segment_results]
    plt.scatter(avg_speeds, n_vals, color='coral', alpha=0.6, s=40, edgecolors='k')
    plt.xlabel('Average Speed (km/h)')
    plt.ylabel('Path Loss Exponent (n)')
    plt.title('Impact of Speed on Path Loss Exponent')
    plt.grid(True, alpha=0.3)

    # Plot 5: Local Sigma vs. Average Speed
    plt.subplot(3, 2, 5)
    plt.scatter(avg_speeds, sigma_vals, color='purple', alpha=0.6, s=40, edgecolors='k')
    plt.xlabel('Average Speed (km/h)')
    plt.ylabel('Local Shadowing Sigma (dB)')
    plt.title('Impact of Speed on Shadowing Variance')
    plt.grid(True, alpha=0.3)

    # Plot 6: CDF of Shadowing Noise
    plt.subplot(3, 2, 6)
    sorted_residuals = np.sort(all_shadowing_residuals)
    yvals = np.arange(len(sorted_residuals))/float(len(sorted_residuals)-1)
    plt.plot(sorted_residuals, yvals, color='darkorange', linewidth=3)
    plt.axhline(0.5, color='gray', linestyle='--', alpha=0.5)
    plt.axvline(0, color='gray', linestyle='--', alpha=0.5)
    plt.xlabel('Shadowing Noise (dB)')
    plt.ylabel('P(X <= x)')
    plt.title('Cumulative Distribution Function (CDF)')
    plt.grid(True, alpha=0.3)

    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plot_path = os.path.join(folder_name, f'result_{os.path.basename(folder_name)}.png')
    plt.savefig(plot_path, dpi=200)
    print(f"Enhanced plots saved to: {plot_path}")
    # plt.show() # Commented out for non-interactive execution

if __name__ == "__main__":
    # Base directory relative to this script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    folders = ['bus', 'car', 'pedestrian', 'static', 'train']
    
    print("Select a mobility pattern to analyze:")
    for i, f in enumerate(folders, 1):
        print(f"{i}. {f.capitalize()}")
    
    try:
        user_input = input("\nEnter choice (1-5): ")
        choice = int(user_input)
    except ValueError:
        print("Please enter a valid number (1-5).")
        exit()

    if 1 <= choice <= len(folders):
        selected_folder = folders[choice-1]
        target_path = os.path.join(script_dir, selected_folder)
        
        if os.path.exists(target_path):
            analyze_mobility_shadowing(target_path)
        else:
            print(f"Error: Folder {target_path} not found.")
    else:
        print("Invalid choice. Please enter a number between 1 and 5.")
